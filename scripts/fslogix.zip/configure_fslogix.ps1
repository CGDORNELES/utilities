configuration configureFSlogix {

    param
    (
        [Parameter(Mandatory = $true)]
        [string]$storageAccountName
    )

    Node localhost {

        Import-DscResource -ModuleName 'PSDesiredStateConfiguration'

        Registry FSLogix_Key01
        {
            Ensure      = "Present"  # You can also set Ensure to "Absent"
            Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\FSLogix\profiles"
            ValueName   = "Enabled"
            ValueData   = "1"
            ValueType   = 'Dword'
        }
        Registry FSLogix_Key02
        {
            Ensure      = "Present"  # You can also set Ensure to "Absent"
            Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\FSLogix\profiles"
            ValueName   = "VHDLocations"
            ValueData   = "\\$storageAccountName.file.core.windows.net\fslogix"
            ValueType   = "MultiString"
        }
    
    }
}
